/* Aluna: Lurian de Lourdes Fluxo
 * IT012 Trabalho Final
 * Atividade 2: Leitura de temperatura e umidade com publicacao na Thingspeak e escrita em display oled SSD1306
 * DOIT ESP32 DEVKIT V1
 *
 * Uso de um webserver com página em memória não-volátil no ESP32.
 * Utiliza o LittleFS para armazenamento dos arquivos da página Web
 * (index.html, style.css e favicon.png).
 *
 * Provê uma página para configurar o SSID e PASSWORD.
 */

/*******************************************************************************
    Inclusões
*******************************************************************************/
#include <Arduino.h>
#include <WiFi.h>
#include "LittleFS.h"
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>

#include "DHT.h"
#include "ThingSpeak.h"

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_Sensor.h>
#include <Fonts/FreeSerif9pt7b.h>


/*******************************************************************************
    Definições de constantes e variáveis globais
*******************************************************************************/
const char *WIFI_SSID = "it012-accesspoint";
const char *WIFI_PASSWORD = "12345678";

// Cria objeto do Webserver na porta 80 (padrão HTTP)
AsyncWebServer server(80);

// Variáveis para armazenar valores obtidos da página HTML
String g_ssid;
String g_password;

String g_canalID;   // Channel ID da vista privada  no ThingSpeak
String g_APIwrite;  // API Key de escrita na vista privada no ThingSpeak
String g_APIread;   // API Key de leitura na vista privada no ThingSpeak
String g_OLEDname;  // Nome a ser inserido no display com o nome do projeto

WiFiClient client;

// Caminhos dos arquivos criados durante a execução do programa
// para salvar os valores das credenciais da Wifi e dos campos para ThingsSpeak e OLED
const char *g_ssidPath = "/ssid.txt";         //arquivo ssid wifi
const char *g_passwordPath = "/password.txt"; //arquivo senha wifi

const char *g_canalIDPath = "/canalID.txt";   //arquivo com o canal na ThingSpeak
const char *g_APIwritePath = "/APIwrite.txt"; //arquivo com a API write na ThingSpeak
const char *g_APIreadPath = "/APIread.txt";   //arquivo com a API read na ThingSpeak 
const char *g_OLEDnamePath = "/OLEDname.txt"; //arquivo com o nome do projeto para o display

/*// Configurações para acesso à um canal predefinido da ThingSpeak
unsigned long THINGSPEAK_CHANNEL_ID = 1905058;              //Passagem via LittleFS 
const char *THINGSPEAK_WRITE_API_KEY = "44VF47LGDMY29YSC";  //Passagem via LittleFS 
const char *THINGSPEAK_READ_API_KEY = "0NTNT4UVXY8AN1LR";   //Passagem via LittleFS */

// Sensor DHT11
#define DHT_READ (15)   //D15 leitura do sensor DHT11 para temperatura e umidade
#define DHT_TYPE DHT11
DHT dht(DHT_READ, DHT_TYPE);
float g_temperature;    //variavel temperatura
float g_humidity;       //variavel umidade

// Display OLED SSD1306
#define OLED_WIDTH (128) // largura do display OLED (pixels)
#define OLED_HEIGHT (64) // altura do display OLED (pixels)
#define OLED_ADDRESS (0x3C) // endereço I²C do display
static Adafruit_SSD1306 display // objeto de controle do SSD1306
    (OLED_WIDTH, OLED_HEIGHT, &Wire, -1);

// Temporização - intervalo de espera por conexão Wifi e tambem sera usado como a atualizacao de dados na thingspeak
unsigned long g_previousMillis = 0;
const long g_interval = 30000; // intervalo ThingSpeak: 30000

/*******************************************************************************
    Implementação: Funções auxiliares
*******************************************************************************/
//Inicializacao do sistema de criacao de arquivos LittleFS
void littlefsInit()
{
  if (!LittleFS.begin(true))
  {
    Serial.println("Erro ao montar o sistema de arquivos LittleFS");
    return;
  }
  Serial.println("Sistema de arquivos LittleFS montado com sucesso.");
}

// Lê arquivos com o LittleFS
String readFile(const char *path)
{
  Serial.printf("Lendo arquivo: %s\r\n", path);

  File file = LittleFS.open(path);
  if (!file || file.isDirectory())
  {
    Serial.printf("\r\nfalha ao abrir o arquivo... %s", path);
    return String();
  }

  String fileContent;
  while (file.available())
  {
    fileContent = file.readStringUntil('\n');
    break;
  }
  return fileContent;
}

// Escreve arquivos com o LittleFS
void writeFile(const char *path, const char *message)
{
  Serial.printf("Escrevendo arquivo: %s\r\n", path);

  File file = LittleFS.open(path, FILE_WRITE);
  if (!file)
  {
    Serial.printf("\r\nfalha ao abrir o arquivo... %s", path);
    return;
  }
  if (file.print(message))
  {
    Serial.printf("\r\narquivo %s editado.", path);
  }
  else
  {
    Serial.printf("\r\nescrita no arquivo %s falhou... ", path);
  }
}

// Callbacks para requisições de recursos do servidor
void serverOnGetRoot(AsyncWebServerRequest *request)
{
  request->send(LittleFS, "/index.html", "text/html");
}

void serverOnGetStyle(AsyncWebServerRequest *request)
{
  request->send(LittleFS, "/style.css", "text/css");
}

void serverOnGetFavicon(AsyncWebServerRequest *request)
{
  request->send(LittleFS, "/favicon.png", "image/png");
}

void serverOnPost(AsyncWebServerRequest *request)
{
  int params = request->params();

  for (int i = 0; i < params; i++)
  {
    AsyncWebParameter *p = request->getParam(i);
    if (p->isPost())
    {
      if (p->name() == "ssid")
      {
        g_ssid = p->value().c_str();
        Serial.print("SSID definido como ");
        Serial.println(g_ssid);

        // Escreve WIFI_SSID no arquivo
        writeFile(g_ssidPath, g_ssid.c_str());
      }
      if (p->name() == "password")
      {
        g_password = p->value().c_str();
        Serial.print("Senha definida como ");
        Serial.println(g_password);

        // Escreve WIFI_PASSWORD no arquivo
        writeFile(g_passwordPath, g_password.c_str());
      }

      if (p->name() == "canalID")
      {
        g_canalID = p->value().c_str();
        Serial.print("canalID definida como ");
        Serial.println(g_canalID);
        // Escreve canalID no arquivo
        writeFile(g_canalIDPath, g_canalID.c_str());
      }

      if (p->name() == "APIwrite")
      {
        g_APIwrite = p->value().c_str();
        Serial.print("APIwrite definida como ");
        Serial.println(g_APIwrite);
        // Escreve APIwrite no arquivo
        writeFile(g_APIwritePath, g_APIwrite.c_str());
      }

      if (p->name() == "APIread")
      {
        g_APIread = p->value().c_str();
        Serial.print("APIread definida como ");
        Serial.println(g_APIread);
        // Escreve APIread no arquivo
        writeFile(g_APIreadPath, g_APIread.c_str());
      }

      if (p->name() == "OLEDname")
      {
        g_OLEDname = p->value().c_str();
        Serial.print("OLEDname definida como ");
        Serial.println(g_OLEDname);
        // Escreve OLEDname no arquivo
        writeFile(g_OLEDnamePath, g_OLEDname.c_str());
      }

    }
  }

  // Após escrever no arquivo, envia mensagem de texto simples ao browser
  request->send(200, "text/plain", "Finalizado - o ESP32 vai reiniciar e se conectar ao seu AP definido.");

  // Reinicia o ESP32
  delay(2000);
  ESP.restart();
}

esp_err_t sensorRead()
{
    // Leitura do DHT11
    float temperature = dht.readTemperature();
    float humidity = dht.readHumidity();
    if (isnan(humidity) || isnan(temperature))
    {
        Serial.printf("\r\n[sensorRead] DHT11 - leitura inválida...");
        return ESP_FAIL;
    }

    Serial.printf("\r\n[sensorRead] Temperatura: %2.2f°C", temperature);
    Serial.printf("\r\n[sensorRead] Umidade: %2.2f %%", humidity);
    Serial.printf("\r\n");

    g_temperature = temperature;
    g_humidity = humidity;
    return ESP_OK;
}



// Inicializa a conexão Wifi
bool initWiFi()
{
  // Se o valor de g_ssid for não-nulo, uma rede Wifi foi provida pela página do
  // servidor. Se for, o ESP32 iniciará em modo AP.
  if (g_ssid == "")
  {
    Serial.println("SSID indefinido (ainda não foi escrito no arquivo, ou a leitura falhou).");
    return false;
  }

  // Se há um SSID e PASSWORD salvos, conecta-se à esta rede.
  WiFi.mode(WIFI_STA);
  WiFi.begin(g_ssid.c_str(), g_password.c_str());
  Serial.println("Conectando à Wifi...");

  //Inicializacao da ThingSpeak
  ThingSpeak.begin(client);

  unsigned long currentMillis = millis();
  g_previousMillis = currentMillis;

  while (WiFi.status() != WL_CONNECTED)
  {
    currentMillis = millis();
    if (currentMillis - g_previousMillis >= g_interval)
    {
      Serial.println("Falha em conectar.");
      return false;
    }
  }

  // Exibe o endereço IP local obtido
  Serial.println(WiFi.localIP());
  return true;
}
 

esp_err_t updateChannel()
{
    // Lê dados do sensor e publica se a leitura não falhou
    if (sensorRead() == ESP_OK)
    {
        // Envia dados à plataforma ThingSpeak. Cada dado dos sensores é setado em um campo (field) distinto.
        int errorCode;
        ThingSpeak.setField(1, g_temperature);
        ThingSpeak.setField(2, g_humidity);

        // Transfere o canalID e a API de escrita para o thingspeak
        errorCode = ThingSpeak.writeFields((long)g_canalID.c_str(), g_APIwrite.c_str());

        if (errorCode != 200)
        {
            Serial.println("Erro ao atualizar os canais - código HTTP: " + String(errorCode));
            return ESP_FAIL;
        }
    }
    // Leitura falhou; apenas retorna
    return ESP_OK;
}

/*******************************************************************************
    Implementação: setup & loop
*******************************************************************************/
void setup()
{
  // Log inicial da placa
  Serial.begin(115200);
  Serial.print("\r\n --- Atividade 2_webserver_provisioning --- \n");

  // Inicia o sistema de arquivos
  littlefsInit();

  // Configura LED_BUILTIN (GPIO2) como pino de saída
  pinMode(LED_BUILTIN, OUTPUT);
  digitalWrite(LED_BUILTIN, LOW);

  // Carrega os valores lidos com o LittleFS
  g_ssid = readFile(g_ssidPath);          //nome do wifi
  g_password = readFile(g_passwordPath);  //senha do wifi

  g_canalID = readFile(g_canalIDPath);    //ID canal na ThingSpeak
  g_APIwrite = readFile(g_APIwritePath);  //API escrita na ThingSpeak
  g_APIread = readFile(g_APIreadPath);    //API leitura na ThingSpeak
  g_OLEDname = readFile(g_OLEDnamePath);  //Nome do projeto a ser passado para o display OLED

  //escreve no serialmonitor os 6 dados passado via littefs
  Serial.println(g_ssid);       
  Serial.println(g_password);
  Serial.println(g_canalID);
  Serial.println(g_APIwrite);
  Serial.println(g_APIread);
  Serial.println(g_OLEDname);


  if (!initWiFi())
  {
    // Seta o ESP32 para o modo AP
    WiFi.mode(WIFI_AP);
    WiFi.softAP(WIFI_SSID, WIFI_PASSWORD);

    Serial.print("Access Point criado com endereço IP ");
    Serial.println(WiFi.softAPIP());

    // Callbacks da página principal do servidor de provisioning
    server.on("/", HTTP_GET, serverOnGetRoot);
    server.on("/style.css", HTTP_GET, serverOnGetStyle);
    server.on("/favicon.png", HTTP_GET, serverOnGetFavicon);

    // Ao clicar no botão "Enviar" para enviar as credenciais, o servidor receberá uma
    // requisição do tipo POST, tratada a seguir
    server.on("/", HTTP_POST, serverOnPost);

    // Como ainda não há credenciais para acessar a rede wifi,
    // Inicia o Webserver em modo AP
    server.begin();
  }

    // Inicializa o sensor DHT11
    dht.begin();

    // Inicializa o display OLED SSD1306
    display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS);
    display.setTextColor(WHITE);

}

void loop()
{
  if (WiFi.status() == WL_CONNECTED)
  {
    digitalWrite(LED_BUILTIN, HIGH);
    delay(100);
    digitalWrite(LED_BUILTIN, LOW);
    delay(900);

    unsigned long currentMillis = millis();

    if (WiFi.status() == WL_CONNECTED)
    {
        // A cada "g_interval" ms, atualiza os canais criados na plataforma da
        // ThingsPeak, se huver uma conexão Wifi ativa
        if ((currentMillis - g_previousMillis >= g_interval) && (WiFi.status() == WL_CONNECTED))
        {
            g_previousMillis = currentMillis;
            updateChannel();
        }
    }
    // Atraso entre medidas do DHT11
    //delay(2000);

    float umidade = dht.readHumidity();
    float temperatura = dht.readTemperature();

    // Limpa a tela do display e mostra o nome do exemplo
    display.clearDisplay();
    display.setCursor(0, 0);
    display.print(g_OLEDname);

    // Mostra temperatura no display OLED
    display.drawRoundRect(0, 16, 72, 40, 6, WHITE);
    display.setCursor(4, 20);
    display.printf("Temperatura");
    display.setCursor(4, 40);
    display.setFont(&FreeSerif9pt7b);
    display.printf("%0.1f", temperatura);
    display.printf(" C");
    display.setFont();

    // Mostra umidade no display OLED
    display.drawRoundRect(74, 16, 54, 40, 6, WHITE);
    display.setCursor(80, 20);
    display.printf("Umidade");
    display.setCursor(78, 40);
    display.setFont(&FreeSerif9pt7b);
    display.printf("%0.1f", umidade);
    display.printf("%%");
    display.setFont();

    // Atualiza tela do display OLED
    display.display();


  }
  else
  {
    digitalWrite(LED_BUILTIN, HIGH);
    delay(1000);
    digitalWrite(LED_BUILTIN, LOW);
    delay(1000);
  }

}